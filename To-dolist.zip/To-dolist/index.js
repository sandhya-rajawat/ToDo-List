const inputBox=document.getElementById('input_box')
const listItme=document.getElementById('list-container')
const btn=document.getElementById('btn').addEventListener('click', function addText(){
  if(inputBox.value===''){
        alert("You Must Write Somthing!💩")
      }else{
        let li=document.createElement('li')
        li.innerHTML=inputBox.value;
        listItme.appendChild(li);
        let span=document.createElement('span')
        span.innerHTML='\u00d7';
        li.appendChild(span)
      }
      inputBox.value=""
      savaData();
    })
listItme.addEventListener('click',function(e){
  if(e.target.tagName==='LI'){
    e.target.classList.toggle("checked");
    savaData();
  }
  else if(e.target.tagName==='SPAN'){
    e.target.parentElement.remove();
    savaData();
    }
},0);
function savaData(){
  localStorage.setItem("data",listItme.innerHTML)
}
function showData(){
  listItme.innerHTML=localStorage.getItem("data");
}
showData()